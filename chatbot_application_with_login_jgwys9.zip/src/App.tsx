import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import ChatPage from './pages/ChatPage';
import ChatbotListPage from './pages/ChatbotListPage';
import './App.css';

function App() {
  return (
    <Router>
      <Routes>
        {/* Set the root path to the LoginPage */}
        <Route path="/login" element={<LoginPage />} />
        {/* Set the ChatbotListPage path to /chatbots */}
        <Route path="/chatbots" element={<ChatbotListPage />} />
        {/* Set the ChatPage path to /chat */}
        <Route path="/chat" element={<ChatPage />} />
        {/* Redirect root path to /login */}
        <Route path="/" element={<LoginPage />} /> {/* Ensure root also goes to login */}
      </Routes>
    </Router>
  );
}

export default App;

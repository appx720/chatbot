import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

// Placeholder data for 4 chatbots
const chatbots = [
  {
    id: 'source-assistant',
    name: 'Source Assistant',
    description: 'Your helpful assistant for code and documentation.',
    avatarUrl: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Placeholder Pexels image
    avatarFallback: 'SA',
    link: '/chat', // Link to the chat page
  },
  {
    id: 'design-bot',
    name: 'Design Bot',
    description: 'Get creative ideas and design feedback.',
    avatarUrl: 'https://images.pexels.com/photos/1043400/pexels-photo-1043400.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Placeholder Pexels image
    avatarFallback: 'DB',
    link: '/chat', // Link to the chat page (can be updated later for specific bots)
  },
  {
    id: 'data-analyst',
    name: 'Data Analyst',
    description: 'Analyze data and generate reports.',
    avatarUrl: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Placeholder Pexels image
    avatarFallback: 'DA',
    link: '/chat', // Link to the chat page
  },
  {
    id: 'project-manager',
    name: 'Project Manager',
    description: 'Help manage tasks and timelines.',
    avatarUrl: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', // Placeholder Pexels image
    avatarFallback: 'PM',
    link: '/chat', // Link to the chat page
  },
];

function ChatbotListPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 dark:bg-gray-800 p-4">
      <h1 className="text-3xl font-bold mb-8 text-gray-900 dark:text-white">Choose a Chatbot</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6 w-full max-w-2xl">
        {chatbots.map((bot) => (
          <Link key={bot.id} to={bot.link} className="no-underline">
            <Card className="flex items-center p-4 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200">
              <Avatar className="h-12 w-12 mr-4">
                <AvatarImage src={bot.avatarUrl} alt={`${bot.name} Avatar`} />
                <AvatarFallback>{bot.avatarFallback}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <CardTitle className="text-lg">{bot.name}</CardTitle>
                <CardDescription className="text-sm">{bot.description}</CardDescription>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}

export default ChatbotListPage;

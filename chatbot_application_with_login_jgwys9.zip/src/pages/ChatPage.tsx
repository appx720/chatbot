import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Paperclip, Send } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useNavigate } from 'react-router-dom';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

interface Message {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: string;
}

function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: "Hi! I'm your Source Assistant. What can I do for you?", sender: 'bot', timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) },
  ]);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null); // Ref for the hidden file input
  const navigate = useNavigate();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (input.trim()) {
      const newMessage: Message = {
        id: messages.length + 1,
        text: input,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages([...messages, newMessage]);
      setInput('');
      // Simulate bot response (optional)
      setTimeout(() => {
        const botResponse: Message = {
          id: messages.length + 2,
          text: "Thanks for your message! I'm still learning.",
          sender: 'bot',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages(prevMessages => [...prevMessages, botResponse]);
      }, 1000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const handleBackClick = () => {
    navigate('/chatbots'); // Navigate to the chatbot list page
  };

  // Placeholder for profile menu item click
  const handleProfileClick = () => {
    console.log("Profile settings clicked");
    // Implement profile settings or other actions here
  };

  const handleLogoutClick = () => {
    console.log("Logout clicked");
    // Implement logout logic here
    // This should navigate to the login page
    navigate('/login');
  };

  // Handle file button click
  const handleFileButtonClick = () => {
    fileInputRef.current?.click(); // Trigger the hidden file input click
  };

  // Handle file selection
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      console.log("Selected files:", files);

      // Create a message indicating the files sent
      const fileNames = Array.from(files).map(file => file.name).join(', ');
      const fileMessageText = `Sent file(s): ${fileNames}`;

      const newFileMessage: Message = {
        id: messages.length + 1, // Use messages.length + 1 for the new message ID
        text: fileMessageText,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      // Add the file message to the chat
      setMessages(prevMessages => [...prevMessages, newFileMessage]);

      // Simulate bot response (optional) - adjust ID calculation
      setTimeout(() => {
        const botResponse: Message = {
          id: messages.length + 2, // Adjust ID for the bot response
          text: `Received your file(s): ${fileNames}. I'm processing them.`,
          sender: 'bot',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages(prevMessages => [...prevMessages, botResponse]);
      }, 1000);
    }
    // Reset the input value so the same file can be selected again
    event.target.value = '';
  };


  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-800">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-white dark:bg-gray-900 shadow-md">
        <div className="flex items-center space-x-2">
          {/* Chatbot Name Button with Arrow Icon - Removed the redundant icon-only button */}
          <Button variant="ghost" onClick={handleBackClick} className="flex items-center">
             {/* Add the left arrow icon here, inside the button */}
            <ArrowLeft className="h-4 w-4 mr-2" /> {/* Smaller icon with margin */}
            <h1 className="text-lg font-semibold">Source Assistant</h1>
          </Button>
        </div>
        {/* Profile Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Avatar className="h-8 w-8 cursor-pointer"> {/* Make Avatar clickable */}
               {/* Using a placeholder image URL from Pexels */}
              <AvatarImage src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="User Avatar" />
              <AvatarFallback>US</AvatarFallback> {/* Changed fallback to User */}
            </Avatar>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleProfileClick}>
              Profile Settings
            </DropdownMenuItem>
            {/* Add more menu items here */}
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogoutClick}>
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Chat Area */}
      <ScrollArea className="flex-1 p-4 space-y-4 overflow-y-auto">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-end gap-2 ${
              message.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {message.sender === 'bot' && (
              <Avatar className="h-8 w-8">
                 {/* Using a placeholder image URL from Pexels */}
                <AvatarImage src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="Bot Avatar" />
                <AvatarFallback>SA</AvatarFallback>
              </Avatar>
            )}
            <div
              className={`flex flex-col max-w-xs px-4 py-2 rounded-xl ${
                message.sender === 'user'
                  ? 'bg-blue-500 text-white rounded-br-none'
                  : 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 rounded-bl-none'
              }`}
            >
              <p className="text-sm">{message.text}</p>
              <span className={`text-[10px] mt-1 ${message.sender === 'user' ? 'text-blue-200' : 'text-gray-500 dark:text-gray-400'} self-end`}>
                {message.timestamp}
              </span>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} /> {/* Scroll anchor */}
      </ScrollArea>

      {/* Input Area */}
      {/* Added relative and z-10 to ensure this container is above other potential elements */}
      <div className="relative flex items-center p-4 bg-white dark:bg-gray-900 shadow-md z-10">
        {/* Hidden file input */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden" // Hide the input visually
          multiple // Allow selecting multiple files
          accept="image/*,application/pdf,.doc,.docx" // Example: accept images, PDFs, Word docs
        />
        {/* Added relative and z-0 to the input, ensuring buttons with higher z-index are above it */}
        <Input
          className="relative flex-1 mr-2 rounded-full px-4 py-2 border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-blue-500 focus:border-blue-500 z-0"
          placeholder="Say something..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        {/* File upload button - Added relative and z-10, added flex centering */}
        <Button variant="ghost" size="icon" className="relative mr-2 z-10 flex items-center justify-center" onClick={handleFileButtonClick}>
          {/* Apply size and color directly to the icon, add 'block', add flex-shrink-0 */}
          <Paperclip className="h-5 w-5 text-blue-500 dark:text-blue-400 block flex-shrink-0" /> {/* Paperclip icon */}
        </Button>
        {/* Send button - Added relative and z-10, added flex centering */}
        <Button size="icon" className="relative z-10 flex items-center justify-center" onClick={handleSend}>
           {/* Apply size and color directly to the icon, add 'block', add flex-shrink-0 */}
          <Send className="h-5 w-5 text-white dark:text-gray-900 block flex-shrink-0" /> {/* Send icon */}
        </Button>
      </div>
    </div>
  );
}

export default ChatPage;
